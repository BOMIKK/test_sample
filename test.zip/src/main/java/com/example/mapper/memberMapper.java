package com.example.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.dto.MemberVO;

@Repository
public interface memberMapper {
    
    List<MemberVO> getList();
    
}